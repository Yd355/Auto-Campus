# -*- coding: utf-8 -*-
"""图形界面（卡片式深色/浅色主题）+ 后台自动认证线程。"""
import os
import queue
import sys
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk

from . import autostart, config, netcheck, portal

VERSION = "v2.1"
APP_TITLE = "Auto Campus"


def resource_path(rel):
    """开发模式取项目根，打包后取 PyInstaller 解压目录。"""
    if getattr(sys, "frozen", False):
        return os.path.join(getattr(sys, "_MEIPASS", os.path.dirname(sys.executable)), rel)
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), rel)


def apply_icon(root):
    """给窗口设置 WiFi 图标（打包时图标同时嵌入 exe）。"""
    for rel in ("wifi.ico", os.path.join("assets", "wifi.ico")):
        p = resource_path(rel)
        if os.path.exists(p):
            try:
                root.iconbitmap(p)
            except Exception:
                continue
            return

MODE_LABELS = [
    ("自动识别（推荐）", "auto"),
    ("深澜 Srun", "srun"),
    ("锐捷 ePortal", "eportal"),
    ("城市热点 Dr.COM", "drcom"),
    ("通用表单（自动填表）", "generic"),
    ("自定义请求", "custom"),
]
LABEL2KEY = dict(MODE_LABELS)
KEY2LABEL = {v: k for k, v in MODE_LABELS}

KIND_COLOR = {"ok": "green", "bad": "red", "warn": "amber", "idle": "muted"}

PALETTES = {
    "night": {
        "win": "#161922", "card": "#222632", "input": "#2b3040",
        "border": "#3d4356", "fg": "#e8eaf0", "muted": "#9aa3b2",
        "accent": "#3b82f6", "green": "#22c55e", "red": "#ef4444",
        "amber": "#d97706", "graybtn": "#39404f", "graybtn_fg": "#e8eaf0",
        "log": "#1b1f2a", "title": "#ffffff",
    },
    "day": {
        "win": "#eef1f6", "card": "#ffffff", "input": "#f4f6fa",
        "border": "#d4dae4", "fg": "#1f2937", "muted": "#697386",
        "accent": "#2563eb", "green": "#16a34a", "red": "#dc2626",
        "amber": "#d97706", "graybtn": "#e3e8f0", "graybtn_fg": "#1f2937",
        "log": "#f8fafc", "title": "#111827",
    },
}

FONT = "Microsoft YaHei UI"


def _lighten(hexcolor, f=0.14):
    try:
        c = hexcolor.lstrip("#")
        r, g, b = int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)
        r = int(r + (255 - r) * f)
        g = int(g + (255 - g) * f)
        b = int(b + (255 - b) * f)
        return "#%02x%02x%02x" % (r, g, b)
    except Exception:
        return hexcolor


class RoundedButton(tk.Canvas):
    """圆角扁平按钮。用 Canvas 画圆角矩形，文字居中，带悬停反馈。"""

    def __init__(self, master, text="", bg="#3b82f6", fg="#ffffff", command=None,
                 radius=14, height=36, padx=18, font=(FONT, 9, "bold")):
        self._text = text
        self._bg = bg
        self._fg = fg
        self._cmd = command
        self._radius = radius
        self._height = height
        self._padx = padx
        self._font = font
        self._hover = False
        parent_bg = master.cget("bg") if master.cget("bg") else "#ffffff"
        super().__init__(master, height=height, bg=parent_bg,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.bind("<Button-1>", self._on_click)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self._redraw()

    def _measure(self):
        return tkfont.Font(font=self._font).measure(self._text)

    def _redraw(self):
        self.delete("all")
        w = self._measure() + self._padx * 2
        self.configure(width=w)
        h = self._height
        r = self._radius
        fill = _lighten(self._bg) if self._hover else self._bg
        pts = [r, 2, w - r, 2, w - 2, 2, w - 2, r, w - 2, h - r, w - 2, h - 2,
               w - r, h - 2, r, h - 2, 2, h - 2, 2, h - r, 2, r, 2, 2]
        self.create_polygon(pts, smooth=True, fill=fill, outline=fill)
        self.create_text(w / 2, h / 2, text=self._text, fill=self._fg, font=self._font)

    def set_text(self, text):
        self._text = text
        self._redraw()

    def set_style(self, bg, fg):
        self._bg = bg
        self._fg = fg
        self._redraw()

    def _on_click(self, _e):
        if self._cmd:
            self._cmd()

    def _on_enter(self, _e):
        self._hover = True
        self._redraw()

    def _on_leave(self, _e):
        self._hover = False
        self._redraw()


class App:
    def __init__(self, root, start_minimized=False):
        self.root = root
        self.cfg = config.load()
        self.theme = self.cfg.get("theme") if self.cfg.get("theme") in PALETTES else "night"
        self.P = PALETTES[self.theme]
        self.q = queue.Queue()
        self._stop = threading.Event()
        self._worker = None
        self._closed = False
        self._status = ("未开始监控", "idle")

        root.title("%s %s" % (APP_TITLE, VERSION))
        root.configure(bg=self.P["win"])
        root.geometry("660x700")
        root.minsize(600, 620)
        root.protocol("WM_DELETE_WINDOW", self._on_close)

        self._build()
        self._load_to_ui()
        self._apply_status()
        root.after(120, self._drain)

        if start_minimized:
            root.after(400, root.iconify)
        if self.cfg.get("auto_on_start", True):
            root.after(600, self.start_monitor)

    # ================================================================== #
    # 构建 UI
    # ================================================================== #
    def _btn(self, parent, text, bg, fg, cmd, padx=16):
        return RoundedButton(parent, text=text, bg=bg, fg=fg, command=cmd, padx=padx)

    def _entry(self, parent, width=34, show=""):
        e = tk.Entry(parent, width=width, show=show, relief="flat", bd=0,
                     bg=self.P["input"], fg=self.P["fg"], insertbackground=self.P["fg"],
                     highlightthickness=1, highlightbackground=self.P["border"],
                     highlightcolor=self.P["accent"], font=(FONT, 10))
        return e

    def _check(self, parent, text, var, cmd=None):
        return tk.Checkbutton(parent, text=text, variable=var, command=cmd,
                              bg=self.P["card"], fg=self.P["fg"],
                              activebackground=self.P["card"], activeforeground=self.P["fg"],
                              selectcolor=self.P["input"], relief="flat", bd=0,
                              highlightthickness=0, font=(FONT, 9), cursor="hand2")

    def _label(self, parent, text, kind="fg", size=9, bold=False):
        color = self.P.get(kind, self.P["fg"])
        return tk.Label(parent, text=text, bg=self.P["card"], fg=color,
                        font=(FONT, size, "bold" if bold else "normal"))

    def _row(self, parent, label):
        f = tk.Frame(parent, bg=self.P["card"])
        self._label(f, label, "muted", 9).pack(side="left", anchor="w")
        return f

    def _build(self):
        P = self.P
        for w in self.root.winfo_children():
            w.destroy()

        outer = tk.Frame(self.root, bg=P["win"])
        outer.pack(fill="both", expand=True, padx=18, pady=14)

        # ---------- 头部 ----------
        head = tk.Frame(outer, bg=P["win"])
        head.pack(fill="x")
        left = tk.Frame(head, bg=P["win"])
        left.pack(side="left")
        tk.Label(left, text=APP_TITLE, bg=P["win"], fg=P["title"],
                 font=(FONT, 18, "bold")).pack(anchor="w")
        tk.Label(left, text="一键认证 · 掉线自动重连", bg=P["win"],
                 fg=P["muted"], font=(FONT, 9)).pack(anchor="w")
        t_text = "☀  日间模式" if self.theme == "night" else "🌙  夜间模式"
        self.btn_theme = self._btn(head, t_text, P["card"], P["fg"], self._toggle_theme)
        self.btn_theme.pack(side="right")

        # ---------- 连接状态横幅 ----------
        self.banner = tk.Label(outer, text="", bg=P["graybtn"], fg="#ffffff",
                               font=(FONT, 12, "bold"), anchor="w", padx=16, pady=12)
        self.banner.pack(fill="x", pady=(14, 0))

        # ---------- 标签页 ----------
        tabbar = tk.Frame(outer, bg=P["win"])
        tabbar.pack(fill="x", pady=(12, 0))
        self.tab_btns = {}
        for key, label in (("basic", "基础设置"), ("adv", "高级设置"),
                           ("log", "运行日志"), ("about", "关于")):
            b = self._btn(tabbar, label, P["card"], P["muted"],
                          lambda k=key: self._show_tab(k), padx=18)
            b.pack(side="left", padx=(0, 8))
            self.tab_btns[key] = b

        body = tk.Frame(outer, bg=P["card"])
        body.pack(fill="both", expand=True, pady=(8, 0))
        self.tabs = {}
        for key in ("basic", "adv", "log", "about"):
            self.tabs[key] = tk.Frame(body, bg=P["card"])

        self._build_basic(self.tabs["basic"])
        self._build_adv(self.tabs["adv"])
        self._build_log(self.tabs["log"])
        self._build_about(self.tabs["about"])

        # ---------- 底部提示 ----------
        tk.Label(outer, text="程序只在网络变化或定时检测时工作，平时处于等待状态。",
                 bg=P["win"], fg=P["muted"], font=(FONT, 8)).pack(anchor="w", pady=(8, 0))

        self._show_tab("basic")

    # ---------------- 基础设置 ----------------
    def _build_basic(self, f):
        pad = {"fill": "x", "padx": 20, "pady": (14, 0)}

        self.lbl_user = self._label(f, "账号", "muted")
        self.lbl_user.pack(in_=f, anchor="w", padx=20, pady=(18, 2))
        self.ent_user = self._entry(f, 34)
        self.ent_user.pack(**pad)

        pw = tk.Frame(f, bg=self.P["card"])
        pw.pack(fill="x", padx=20, pady=(12, 0))
        self._label(pw, "密码", "muted").pack(side="left", anchor="w")
        self.var_show = tk.BooleanVar(value=False)
        self._check(pw, "显示", self.var_show, self._toggle_pwd).pack(side="right")
        self.ent_pwd = self._entry(f, 34, show="●")
        self.ent_pwd.pack(fill="x", padx=20, pady=(2, 0))

        self._label(f, "登录页地址", "muted").pack(anchor="w", padx=20, pady=(12, 2))
        self.ent_server = self._entry(f, 34)
        self.ent_server.pack(fill="x", padx=20)
        self._label(f, "地址中可使用 {local_ip}；留空则自动探测门户地址，推荐留空。",
                    "muted", 8).pack(anchor="w", padx=20, pady=(3, 0))

        self.var_auto_mode = tk.BooleanVar(value=True)
        self.chk_auto_mode = self._check(f, "自动识别认证类型（推荐，适配深澜 / 锐捷 / Dr.COM）",
                                         self.var_auto_mode, self._on_auto_mode_toggle)
        self.chk_auto_mode.pack(anchor="w", padx=20, pady=(10, 0))

        self.var_autostart = tk.BooleanVar(value=True)
        self._check(f, "开机自动启动并后台认证", self.var_autostart).pack(
            anchor="w", padx=20, pady=(2, 0))

        btns = tk.Frame(f, bg=self.P["card"])
        btns.pack(anchor="w", padx=20, pady=(14, 0))
        self.btn_save = self._btn(btns, "保存并启用", self.P["accent"], "#ffffff", self.save_and_start)
        self.btn_save.pack(side="left")
        self.btn_test = self._btn(btns, "测试登录", self.P["green"], "#ffffff", self.login_now)
        self.btn_test.pack(side="left", padx=(8, 0))
        self.btn_toggle = self._btn(btns, "停止后台", self.P["graybtn"],
                                    self.P["graybtn_fg"], self.toggle_monitor)
        self.btn_toggle.pack(side="left", padx=(8, 0))
        tk.Frame(f, bg=self.P["card"]).pack(fill="both", expand=True)

    # ---------------- 高级设置 ----------------
    def _build_adv(self, f):
        self._label(f, "认证方式", "muted").pack(anchor="w", padx=20, pady=(18, 2))
        self.cmb_mode = ttk.Combobox(f, width=33, state="disabled",
                                     values=[x[0] for x in MODE_LABELS], font=(FONT, 9))
        self._style_combo()
        self.cmb_mode.pack(fill="x", padx=20)
        self.cmb_mode.bind("<<ComboboxSelected>>", lambda e: self._on_mode_change())
        self._label(f, "勾选“自动识别”时无需选择；取消勾选后可在此手动指定。",
                    "muted", 8).pack(anchor="w", padx=20, pady=(3, 0))

        self._label(f, "检测间隔（秒）", "muted").pack(anchor="w", padx=20, pady=(12, 2))
        self.spn_interval = tk.Spinbox(f, from_=5, to=3600, width=10, relief="flat", bd=0,
                                       bg=self.P["input"], fg=self.P["fg"],
                                       insertbackground=self.P["fg"],
                                       buttonbackground=self.P["card"],
                                       highlightthickness=1,
                                       highlightbackground=self.P["border"],
                                       highlightcolor=self.P["accent"],
                                       font=(FONT, 10))
        self.spn_interval.pack(anchor="w", padx=20)

        self.var_start = tk.BooleanVar(value=True)
        self._check(f, "程序启动后立即检测一次网络", self.var_start).pack(
            anchor="w", padx=20, pady=(12, 0))

        # 自定义请求
        self._label(f, "自定义请求（仅“自定义请求”方式需要）", "muted").pack(
            anchor="w", padx=20, pady=(16, 2))
        self.ent_curl = self._entry(f, 40)
        self.ent_curl.pack(fill="x", padx=20)
        self.cmb_method = ttk.Combobox(f, width=10, state="readonly",
                                       values=["POST", "GET"], font=(FONT, 9))
        self._style_combo()
        self.cmb_method.pack(anchor="w", padx=20, pady=(8, 0))
        self.ent_cdata = self._entry(f, 40)
        self.ent_cdata.pack(fill="x", padx=20, pady=(8, 0))
        self._label(f, "参数用 {user} / {pwd} 代表账号密码，如 username={user}&password={pwd}",
                    "muted", 8).pack(anchor="w", padx=20, pady=(3, 0))
        tk.Frame(f, bg=self.P["card"]).pack(fill="both", expand=True)

    # ---------------- 运行日志 ----------------
    def _build_log(self, f):
        bar = tk.Frame(f, bg=self.P["card"])
        bar.pack(fill="x", padx=20, pady=(16, 0))
        self._btn(bar, "清空日志", self.P["graybtn"], self.P["graybtn_fg"],
                  self.clear_log).pack(side="left")
        self._btn(bar, "打开日志目录", self.P["graybtn"], self.P["graybtn_fg"],
                  self.open_log_dir).pack(side="left", padx=(8, 0))
        wrap = tk.Frame(f, bg=self.P["card"])
        wrap.pack(fill="both", expand=True, padx=20, pady=(10, 16))
        self.txt = tk.Text(wrap, height=10, wrap="word", bg=self.P["log"], fg=self.P["fg"],
                           relief="flat", bd=0, font=("Consolas", 9),
                           padx=10, pady=8, insertbackground=self.P["fg"])
        sb = tk.Scrollbar(wrap, command=self.txt.yview, troughcolor=self.P["card"],
                          bg=self.P["input"], relief="flat", bd=0)
        self.txt.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.txt.pack(fill="both", expand=True)
        self.txt.configure(state="disabled")

    # ---------------- 关于 ----------------
    def _build_about(self, f):
        rows = [
            ("版本", "%s" % VERSION),
            ("支持协议", "深澜 Srun · 锐捷 ePortal · 城市热点 Dr.COM · 通用表单 · 自定义请求"),
            ("联网判定", "直接请求真实外网，不受认证页面“无法使用”误报影响"),
            ("配置文件", config.CONFIG_PATH),
            ("运行日志", config.LOG_PATH),
        ]
        for k, v in rows:
            self._label(f, k, "muted", 8).pack(anchor="w", padx=20, pady=(14, 0))
            self._label(f, v, "fg", 9, bold=True).pack(anchor="w", padx=20, pady=(2, 0))
        self._label(f, "卸载：取消勾选开机自启 → 保存 → 删除本程序 → 删除上面配置文件夹。",
                    "muted", 8).pack(anchor="w", padx=20, pady=(18, 0))
        tk.Frame(f, bg=self.P["card"]).pack(fill="both", expand=True)

    def _style_combo(self):
        st = ttk.Style()
        st.configure("TCombobox", fieldbackground=self.P["input"],
                     background=self.P["card"], foreground=self.P["fg"],
                     arrowcolor=self.P["fg"], bordercolor=self.P["border"],
                     lightcolor=self.P["input"], darkcolor=self.P["input"])

    # ---------------- 标签页切换 ----------------
    def _show_tab(self, key):
        P = self.P
        for k, fr in self.tabs.items():
            fr.pack(fill="both", expand=True) if k == key else fr.pack_forget()
        for k, b in self.tab_btns.items():
            if k == key:
                b.set_style(P["accent"], "#ffffff")
            else:
                b.set_style(P["card"], P["muted"])

    def _toggle_theme(self):
        self.cfg = self._collect()
        self.cfg["theme"] = "day" if self.theme == "night" else "night"
        self.theme = self.cfg["theme"]
        self.P = PALETTES[self.theme]
        config.save(self.cfg)
        self._build()
        self._load_to_ui()
        self._apply_status()
        self._log("已切换到%s" % ("日间模式" if self.theme == "day" else "夜间模式"))

    # ================================================================== #
    # 数据绑定
    # ================================================================== #
    def _load_to_ui(self):
        c = self.cfg
        mode = c.get("mode", "auto")
        self.var_auto_mode.set(mode == "auto")
        self.cmb_mode.set(KEY2LABEL.get(mode if mode != "auto" else "eportal",
                                       MODE_LABELS[1][0]))
        self.cmb_mode.configure(state="disabled" if mode == "auto" else "readonly")
        self.ent_user.insert(0, c.get("username", ""))
        self.ent_pwd.insert(0, c.get("password", ""))
        self.ent_server.insert(0, c.get("server", ""))
        self.spn_interval.delete(0, "end")
        self.spn_interval.insert(0, str(c.get("interval", 30)))
        self.var_autostart.set(bool(c.get("autostart")))
        self.var_start.set(bool(c.get("auto_on_start", True)))
        self.ent_curl.insert(0, c.get("custom_url", ""))
        self.cmb_method.set(c.get("custom_method", "POST"))
        self.ent_cdata.insert(0, c.get("custom_data", ""))

    def _collect(self):
        c = dict(self.cfg)
        if self.var_auto_mode.get():
            c["mode"] = "auto"
        else:
            c["mode"] = LABEL2KEY.get(self.cmb_mode.get(), "auto")
        for attr, key in (("ent_user", "username"), ("ent_pwd", "password"),
                          ("ent_server", "server"), ("ent_curl", "custom_url"),
                          ("ent_cdata", "custom_data")):
            if hasattr(self, attr):
                c[key] = getattr(self, attr).get().strip()
        c["password"] = getattr(self, "ent_pwd").get()
        try:
            c["interval"] = max(5, int(float(self.spn_interval.get())))
        except Exception:
            c["interval"] = 30
        if hasattr(self, "var_autostart"):
            c["autostart"] = bool(self.var_autostart.get())
            c["auto_on_start"] = bool(self.var_start.get())
        c["custom_method"] = self.cmb_method.get() or "POST"
        c["theme"] = self.theme
        return c

    def _on_auto_mode_toggle(self):
        if self.var_auto_mode.get():
            self.cmb_mode.configure(state="disabled")
            self.cmb_mode.set(MODE_LABELS[1][0])
        else:
            self.cmb_mode.configure(state="readonly")

    def _on_mode_change(self):
        pass

    def _toggle_pwd(self):
        self.ent_pwd.configure(show="" if self.var_show.get() else "●")

    def _apply_autostart(self):
        want = bool(self.var_autostart.get())
        if autostart.is_enabled() != want:
            autostart.set_enabled(want)

    # ================================================================== #
    # 按钮动作
    # ================================================================== #
    def save_and_start(self):
        self.cfg = self._collect()
        config.save(self.cfg)
        self._apply_autostart()
        self._log("设置已保存")
        self._set_status("设置已保存，正在检测网络…", "warn")
        if self._worker and self._worker.is_alive():
            self._log("后台监控运行中，将使用新配置")
        else:
            self.start_monitor(silent=True)

    def toggle_monitor(self):
        if self._worker and self._worker.is_alive():
            self.stop_monitor()
        else:
            self.cfg = self._collect()
            self.start_monitor()

    def start_monitor(self, silent=False):
        if self._worker and self._worker.is_alive():
            return
        self.cfg = self._collect()
        config.save(self.cfg)
        self._apply_autostart()
        if not self.cfg["username"]:
            self._log("尚未填写账号，已开始监控但无法自动认证")
            self._set_status("未填写账号，无法自动认证", "bad")
        self._stop.clear()
        self._worker = threading.Thread(target=self._loop, name="monitor", daemon=True)
        self._worker.start()
        self.btn_toggle.set_text("停止后台")
        if not silent:
            self._log("已开始监控，每 %s 秒检测一次" % self.cfg["interval"])

    def stop_monitor(self):
        self._stop.set()
        self.btn_toggle.set_text("启动后台")
        self._set_status("监控已停止", "idle")
        self._log("已停止监控")

    def login_now(self):
        self.cfg = self._collect()
        if not self.cfg["username"]:
            self._set_status("请先填写账号和密码", "bad")
            return
        config.save(self.cfg)
        self._apply_autostart()
        threading.Thread(target=self._once, daemon=True).start()

    def clear_log(self):
        self.txt.configure(state="normal")
        self.txt.delete("1.0", "end")
        self.txt.configure(state="disabled")

    def open_log_dir(self):
        try:
            os.startfile(config.data_dir())
        except Exception:
            pass

    # ================================================================== #
    # 工作线程
    # ================================================================== #
    def _once(self):
        self._set_status("正在认证…", "warn")
        try:
            res = portal.login(self.cfg, self._log)
        except Exception as e:
            self._set_status("认证异常", "bad")
            self._log("异常：%s" % e)
            return
        self._log("结果：%s%s" % (res.message, ("（%s）" % res.detail) if res.detail else ""))
        if res.ok:
            self._set_status("认证成功 · 已连接互联网", "ok")
        else:
            self._set_status("认证失败：%s" % res.message, "bad")

    def _loop(self):
        while not self._stop.is_set():
            try:
                if netcheck.is_online(timeout=4):
                    if self._last_state != "online":
                        self._log("网络正常")
                    self._last_state = "online"
                    self._set_status("已连接互联网", "ok")
                else:
                    self._last_state = "offline"
                    self._set_status("未连接 · 正在认证…", "warn")
                    self._log("检测到未联网，开始认证")
                    res = portal.login(self.cfg, self._log)
                    self._log("结果：%s%s" % (res.message,
                                             ("（%s）" % res.detail) if res.detail else ""))
                    if res.ok:
                        self._set_status("认证成功 · 已连接互联网", "ok")
                        self._last_state = "online"
                    else:
                        self._set_status("认证失败：%s" % res.message, "bad")
            except Exception as e:
                self._log("监控异常：%s" % e)

            try:
                wait = int(self.cfg.get("interval") or 30)
            except Exception:
                wait = 30
            for _ in range(wait):
                if self._stop.is_set():
                    break
                time.sleep(1)

    _last_state = None

    # ================================================================== #
    # 跨线程通信
    # ================================================================== #
    def _log(self, text):
        self.q.put(("log", text))

    def _set_status(self, text, kind):
        self.q.put(("status", text, kind))

    def _apply_status(self):
        text, kind = self._status
        color = self.P[KIND_COLOR.get(kind, "muted")]
        self.banner.configure(text="●   " + text, bg=color, fg="#ffffff")

    def _drain(self):
        if self._closed:
            return
        try:
            while True:
                item = self.q.get_nowait()
                if item[0] == "log":
                    ts = time.strftime("%H:%M:%S")
                    self.txt.configure(state="normal")
                    self.txt.insert("end", "[%s] %s\n" % (ts, item[1]))
                    self.txt.see("end")
                    self.txt.configure(state="disabled")
                    config.write_log(item[1])
                elif item[0] == "status":
                    self._status = (item[1], item[2])
                    self._apply_status()
        except queue.Empty:
            pass
        except tk.TclError:
            return
        try:
            self.root.after(150, self._drain)
        except tk.TclError:
            pass

    def _on_close(self):
        self._closed = True
        self._stop.set()
        try:
            config.save(self._collect())
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass


def run(start_minimized=False):
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    apply_icon(root)
    App(root, start_minimized=start_minimized)
    root.mainloop()

# -*- coding: utf-8 -*-
"""自检：与公开参考实现对比深澜加密结果是否一致。"""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import crypto_srun as mine  # noqa: E402


# ---------- 参考实现（来自 coffeehat/BIT-srun-login-script，逐行照搬） ----------
def ordat(msg, idx):
    if len(msg) > idx:
        return ord(msg[idx])
    return 0


def sencode(msg, key):
    l = len(msg)
    pwd = []
    for i in range(0, l, 4):
        pwd.append(ordat(msg, i) | ordat(msg, i + 1) << 8 | ordat(msg, i + 2) << 16
                   | ordat(msg, i + 3) << 24)
    if key:
        pwd.append(l)
    return pwd


def lencode(msg, key):
    l = len(msg)
    ll = (l - 1) << 2
    if key:
        m = msg[l - 1]
        if m < ll - 3 or m > ll:
            return
        ll = m
    for i in range(0, l):
        msg[i] = chr(msg[i] & 0xff) + chr(msg[i] >> 8 & 0xff) + chr(
            msg[i] >> 16 & 0xff) + chr(msg[i] >> 24 & 0xff)
    if key:
        return "".join(msg)[0:ll]
    return "".join(msg)


def ref_xencode(msg, key):
    if msg == "":
        return ""
    pwd = sencode(msg, True)
    pwdk = sencode(key, False)
    if len(pwdk) < 4:
        pwdk = pwdk + [0] * (4 - len(pwdk))
    n = len(pwd) - 1
    z = pwd[n]
    y = pwd[0]
    c = 0x86014019 | 0x183639A0
    m = 0
    e = 0
    p = 0
    q = math.floor(6 + 52 / (n + 1))
    d = 0
    while 0 < q:
        d = d + c & (0x8CE0D9BF | 0x731F2640)
        e = d >> 2 & 3
        p = 0
        while p < n:
            y = pwd[p + 1]
            m = z >> 5 ^ y << 2
            m = m + ((y >> 3 ^ z << 4) ^ (d ^ y))
            m = m + (pwdk[(p & 3) ^ e] ^ z)
            pwd[p] = pwd[p] + m & (0xEFB8D130 | 0x10472ECF)
            z = pwd[p]
            p = p + 1
        y = pwd[0]
        m = z >> 5 ^ y << 2
        m = m + ((y >> 3 ^ z << 4) ^ (d ^ y))
        m = m + (pwdk[(p & 3) ^ e] ^ z)
        pwd[n] = pwd[n] + m & (0xBB390742 | 0x44C6F8BD)
        z = pwd[n]
        q = q - 1
    return lencode(pwd, False)


_ALPHA = "LVoJPiCN2R8G90yg+hmFHuacZ1OWMnrsSTXkYpUq/3dlbfKwv6xztjI7DeBE45QA"


def _gb(s, i):
    x = ord(s[i])
    if x > 255:
        raise ValueError("bad char")
    return x


def ref_base64(s):
    i = 0
    b10 = 0
    x = []
    imax = len(s) - len(s) % 3
    if len(s) == 0:
        return s
    for i in range(0, imax, 3):
        b10 = (_gb(s, i) << 16) | (_gb(s, i + 1) << 8) | _gb(s, i + 2)
        x.append(_ALPHA[(b10 >> 18)])
        x.append(_ALPHA[((b10 >> 12) & 63)])
        x.append(_ALPHA[((b10 >> 6) & 63)])
        x.append(_ALPHA[(b10 & 63)])
    i = imax
    if len(s) - imax == 1:
        b10 = _gb(s, i) << 16
        x.append(_ALPHA[(b10 >> 18)] + _ALPHA[((b10 >> 12) & 63)] + "==")
    elif len(s) - imax == 2:
        b10 = (_gb(s, i) << 16) | (_gb(s, i + 1) << 8)
        x.append(_ALPHA[(b10 >> 18)] + _ALPHA[((b10 >> 12) & 63)]
                 + _ALPHA[((b10 >> 6) & 63)] + "=")
    return "".join(x)


CASES = [
    ('{"username":"201626203044@cmcc","password":"15879684798qq","ip":"10.128.96.249",'
     '"acid":"1","enc_ver":"srun_bx1"}',
     "e6843f26b8544327a3a25978dd3c5f89e6b745df1732993b88fe082c13a34cb9"),
    ('{"username":"202312345678","password":"Abc@123456","ip":"10.21.33.7","acid":"8",'
     '"enc_ver":"srun_bx1"}',
     "711ab370231392679fe06523b119a8fe096f5ed9bd206b4de8d7b5b994bbc3e5"),
    ('{"username":"x","password":"y","ip":"1.2.3.4","acid":"1","enc_ver":"srun_bx1"}', "abc123"),
]

ok = True
for plain, token in CASES:
    a = mine.xencode(plain, token)
    b = ref_xencode(plain, token)
    if a != b:
        ok = False
        print("xencode 不一致\n mine=%r\n ref =%r" % (a, b))
    else:
        print("xencode OK  len=%d" % len(a))
    ba = mine.srun_base64(a)
    bb = ref_base64(b)
    if ba != bb:
        ok = False
        print("base64 不一致\n mine=%r\n ref =%r" % (ba, bb))
    else:
        print("base64  OK  %s" % ba[:40])

print("md5/sha1:", mine.md5_hex("abc")[:8], mine.sha1_hex("abc")[:8],
      mine.hmac_md5("k", "m")[:8])

print("\n结果：", "全部一致 ✅" if ok else "存在差异 ❌")
sys.exit(0 if ok else 1)

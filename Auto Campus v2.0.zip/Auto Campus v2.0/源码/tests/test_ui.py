# -*- coding: utf-8 -*-
"""界面冒烟测试：创建窗口 -> 1.5 秒后自动关闭，验证无异常。"""
import os
import sys
import tkinter as tk

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.app import App  # noqa: E402

root = tk.Tk()
app = App(root, start_minimized=False)
root.after(1500, app._on_close)
root.mainloop()
print("UI OK")

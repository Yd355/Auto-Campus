# -*- coding: utf-8 -*-
"""门户识别与通用表单解析的自检（不联网）。"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.netcheck import guess_mode  # noqa: E402
from src.portal import _FormGrabber  # noqa: E402

CASES = [
    ("http://10.0.0.55/srun_portal_pc?ac_id=8&theme=bit", "<html>srun_bx1</html>", "srun"),
    ("http://10.0.0.55/cgi-bin/get_challenge", "", "srun"),
    ("http://10.0.0.55:8080/eportal/index.jsp?wlanuserip=10.1.2.3&wlanacname=AC1",
     "<html>eportal</html>", "eportal"),
    ("http://1.1.1.3/", "<html><input name='0MKKey'></html>", "drcom"),
    ("http://10.1.1.1/login", "<form></form>", "generic"),
]

ok = True
for url, html, want in CASES:
    got = guess_mode({"url": url, "html": html})
    flag = "OK " if got == want else "FAIL"
    if got != want:
        ok = False
    print("%s  %-14s <- %s" % (flag, want, url[:60]))

FORM_HTML = """
<form action="/do_login" method="post">
  <input type="hidden" name="csrf" value="abc123">
  <input type="text" name="username" value="">
  <input type="password" name="password" value="">
  <input type="hidden" name="action" value="login">
  <input type="submit" name="ok" value="登录">
</form>
"""
g = _FormGrabber()
g.feed(FORM_HTML)
f = g.forms[0]
names = [i["name"] for i in f["inputs"]]
print("form action=%s method=%s fields=%s" % (f["action"], f["method"], names))
assert f["action"] == "/do_login" and "password" in names, "表单解析失败"
print("\n结果：", "全部通过 ✅" if ok else "有失败项 ❌")

# -*- coding: utf-8 -*-
"""生成演示用界面截图（深色主题，不读写真实配置）。"""
import os
import sys
import tkinter as tk

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import config  # noqa: E402

DEMO = dict(config.DEFAULTS)
DEMO.update({
    "username": "2026020201056",
    "password": "demo-password",
    "theme": "night",
    "autostart": True,
    "auto_on_start": False,
})
config.load = lambda: dict(DEMO)
config.save = lambda cfg: None
config.write_log = lambda m: None

from src.app import App  # noqa: E402
from PIL import ImageGrab  # noqa: E402

root = tk.Tk()
app = App(root)
app._status = ("已连接互联网", "ok")
app._apply_status()


def shot():
    root.update_idletasks()
    root.update()
    x, y = root.winfo_rootx(), root.winfo_rooty()
    w, h = root.winfo_width(), root.winfo_height()
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "demo_night.png")
    ImageGrab.grab(bbox=(x, y, x + w, y + h)).save(out)
    print("saved:", out, (w, h))
    root.after(200, app._on_close)


root.after(2200, shot)
root.mainloop()

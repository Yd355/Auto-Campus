# -*- coding: utf-8 -*-
"""配置读写。密码以 XOR + Base64 混淆后存放，不写明文。"""
import base64
import json
import os
import sys
import time

APP_NAME = "CampusNetLogin"

DEFAULTS = {
    "mode": "auto",          # auto / srun / eportal / drcom / custom
    "username": "",
    "password": "",
    "server": "",            # 认证服务器地址，留空自动探测
    "interval": 30,          # 断线检测间隔（秒）
    "autostart": False,      # 开机自启
    "auto_on_start": True,   # 启动后立即检测一次
    "ac_id": "1",            # 深澜接入点 ID
    "theme": "night",        # night / day
    "custom_url": "",
    "custom_method": "POST",
    "custom_data": "",       # username=账号&password=密码 形式，支持 {user} {pwd}
}

_KEY = b"CampusNetLogin@2026#local-obfuscation"


def base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def data_dir():
    d = os.path.join(os.environ.get("APPDATA") or base_dir(), APP_NAME)
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        d = base_dir()
    return d


CONFIG_PATH = os.path.join(data_dir(), "config.json")
LOG_PATH = os.path.join(data_dir(), "login.log")


def _xor(data):
    k = _KEY
    return bytes(b ^ k[i % len(k)] for i, b in enumerate(data))


def _enc(text):
    return base64.b64encode(_xor(text.encode("utf-8"))).decode("ascii")


def _dec(text):
    try:
        return _xor(base64.b64decode(text.encode("ascii"))).decode("utf-8")
    except Exception:
        return ""


def load():
    cfg = dict(DEFAULTS)
    if not os.path.exists(CONFIG_PATH):
        return cfg
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
        for k in DEFAULTS:
            if k in raw:
                cfg[k] = raw[k]
        if raw.get("password_enc"):
            cfg["password"] = _dec(raw["password_enc"])
    except Exception:
        pass
    return cfg


def save(cfg):
    data = {k: v for k, v in cfg.items() if k != "password"}
    data["password_enc"] = _enc(cfg.get("password", ""))
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, CONFIG_PATH)


def write_log(line):
    """追加一行日志到磁盘（保留最近 300 行）。"""
    try:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        lines = []
        if os.path.exists(LOG_PATH):
            with open(LOG_PATH, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()[-299:]
        lines.append("[%s] %s\n" % (ts, line))
        with open(LOG_PATH, "w", encoding="utf-8", errors="ignore") as f:
            f.writelines(lines)
    except Exception:
        pass

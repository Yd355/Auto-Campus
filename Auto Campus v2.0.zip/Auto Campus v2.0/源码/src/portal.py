# -*- coding: utf-8 -*-
"""各校园网认证协议的登录实现。

支持：深澜 Srun / 锐捷 ePortal / 城市热点 Dr.COM / 通用表单 / 自定义 POST
"""
import json
import random
import re
import time
from html.parser import HTMLParser
from urllib.parse import parse_qs, quote, unquote, urlsplit

import requests

from . import crypto_srun as cs
from .netcheck import HDR, base_of, detect_portal, guess_mode, is_online, local_ip, normalize_server

USER_FIELD_HINT = ("user", "account", "name", "login", "id", "zh", "yhm", "ddddd", "wlanuser")
PWD_FIELD_HINT = ("pass", "pwd", "mm", "secret")


class Result:
    def __init__(self, ok, message, detail=""):
        self.ok = ok
        self.message = message
        self.detail = detail or ""

    def __repr__(self):
        return "Result(ok=%s, message=%r)" % (self.ok, self.message)


def _sess():
    s = requests.Session()
    s.headers.update(HDR)
    return s


def _rand_v():
    return str(random.randint(1000, 9999))


def _wait_online(tries=3, delay=2.0):
    """认证成功后门户放行可能有延迟，多等几次再判定，避免误报失败。"""
    for i in range(tries):
        if _wait_online():
            return True
        if i < tries - 1:
            time.sleep(delay)
    return False


# --------------------------------------------------------------------------- #
# 深澜 Srun
# --------------------------------------------------------------------------- #
def _srun_get_page(sess, base, log):
    """从门户页里取客户端 IP 与 ac_id（取不到就退回本机 IP）。"""
    ip = ""
    acid = ""
    for path in ("/srun_portal_pc?ac_id=%s&theme=" % "1", "/srun_portal_pc", "/"):
        try:
            r = sess.get(base + path, timeout=6)
        except Exception:
            continue
        if r.status_code != 200:
            continue
        m = re.search(r'id=["\']user_ip["\']\s+value=["\']([^"\']+)', r.text)
        if m:
            ip = m.group(1).strip()
        m = re.search(r"ac_id=(\d+)", r.text) or re.search(r'"acid"\s*:\s*"?(\d+)', r.text)
        if m:
            acid = m.group(1)
        if ip:
            break
    return ip, acid


def login_srun(cfg, base, log):
    user = cfg["username"].strip()
    pwd = cfg["password"]
    sess = _sess()
    base = base.rstrip("/")

    ip, acid = _srun_get_page(sess, base, log)
    if not ip:
        ip = local_ip()
    if not acid:
        acid = str(cfg.get("ac_id") or "1")
    log("深澜：客户端 IP=%s，ac_id=%s" % (ip, acid))

    # 1) 取 challenge
    try:
        r = sess.get(base + "/cgi-bin/get_challenge",
                     params={"callback": "jsonp_%d" % int(time.time() * 1000),
                             "username": user, "ip": ip},
                     timeout=8)
    except Exception as e:
        return Result(False, "无法连接认证服务器", str(e))

    token = ""
    m = re.search(r'"challenge"\s*:\s*"([^"]+)"', r.text)
    if m:
        token = m.group(1)
    else:
        m = re.search(r'"challenge"\s*:\s*"([^"]*)"', r.text)
    if not token:
        return Result(False, "获取 token 失败", r.text[:200])
    m = re.search(r'"client_ip"\s*:\s*"([^"]+)"', r.text)
    if m and m.group(1):
        ip = m.group(1)
    m = re.search(r'"acid"\s*:\s*"?(\d+)"?', r.text)
    if m:
        acid = m.group(1)
    log("深澜：拿到 token（%d 位）" % len(token))

    # 2) 依次尝试几种密码摘要形式
    variants = [
        ("hmac-md5", lambda: cs.hmac_md5(token, pwd)),
        ("md5(pwd+token)", lambda: cs.md5_hex(pwd + token)),
        ("md5(token+pwd)", lambda: cs.md5_hex(token + pwd)),
    ]
    last = Result(False, "认证失败")
    for name, fn in variants:
        try:
            hmd5 = fn()
        except Exception:
            continue
        info = '{"username":"%s","password":"%s","ip":"%s","acid":"%s","enc_ver":"srun_bx1"}' % (
            user, pwd.replace("\\", "\\\\").replace('"', '\\"'), ip, acid)
        encrypted_info = "{SRBX1}" + cs.srun_base64(cs.xencode(info, token))
        chkstr = token + user
        chkstr += token + hmd5
        chkstr += token + acid
        chkstr += token + ip
        chkstr += token + "200"
        chkstr += token + "1"
        chkstr += token + encrypted_info
        chksum = cs.sha1_hex(chkstr)

        params = {
            "callback": "jsonp_%d" % int(time.time() * 1000),
            "action": "login",
            "username": user,
            "password": "{MD5}" + hmd5,
            "ac_id": acid,
            "ip": ip,
            "info": encrypted_info,
            "chksum": chksum,
            "n": "200",
            "type": "1",
            "os": "windows",
            "name": "windows",
            "double_stack": "0",
        }
        try:
            r2 = sess.get(base + "/cgi-bin/srun_portal", params=params, timeout=10)
        except Exception as e:
            last = Result(False, "登录请求发送失败", str(e))
            continue

        text = r2.text
        log("深澜[%s] 响应：%s" % (name, text[:160].replace("\n", " ")))

        if '"error":"ok"' in text.replace(" ", "") or '"suc_msg"' in text:
            if _wait_online():
                return Result(True, "认证成功")
            return Result(True, "服务器已接受，等待放行")
        err = re.search(r'"error_msg"\s*:\s*"([^"]*)"', text)
        msg = err.group(1) if err else ""
        if "already" in text.lower() or "ip_already" in text:
            return Result(True, "该 IP 已在线")
        last = Result(False, msg or "认证被拒绝（%s）" % name, text[:200])
        if "password" in (msg or "").lower():
            continue

    return last


# --------------------------------------------------------------------------- #
# 锐捷 ePortal
# --------------------------------------------------------------------------- #
def _eportal_query_string(portal_url):
    q = urlsplit(portal_url).query
    return q


def login_eportal(cfg, portal_url, log):
    user = cfg["username"].strip()
    pwd = cfg["password"]
    sess = _sess()
    root = base_of(portal_url)

    q = parse_qs(urlsplit(portal_url).query)
    wlan_user_ip = (q.get("wlanuserip") or q.get("wlan_user_ip") or [""])[0] or local_ip()
    wlan_ac_name = (q.get("wlanacname") or [""])[0]
    wlan_ac_ip = (q.get("wlanacip") or [""])[0]
    wlan_user_mac = (q.get("mac") or q.get("usermac") or [""])[0] or "000000000000"
    query_string = _eportal_query_string(portal_url)

    headers = {
        "Referer": portal_url,
        "Origin": root,
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
    }

    # --- 方式 A：新版 ePortal（InterFace.do?method=login） ---
    try:
        r = sess.post(root + "/eportal/InterFace.do?method=login",
                      data={
                          "userId": user,
                          "password": pwd,
                          "service": "",
                          "queryString": query_string,
                          "operatorPwd": "",
                          "operatorUserId": "",
                          "validcode": "",
                          "passwordEncrypt": "false",
                      },
                      headers=headers, timeout=10)
        text = r.text
        log("锐捷[InterFace] 响应：%s" % text[:160].replace("\n", " "))
        try:
            j = json.loads(text)
        except Exception:
            j = {}
        if str(j.get("result", "")).lower() in ("success", "true"):
            if _wait_online():
                return Result(True, "认证成功")
            return Result(True, "服务器已接受，等待放行")
        if "已经在线" in text or "already" in text.lower():
            return Result(True, "该账号已在线")
        fail_msg = j.get("message") or text[:120]
    except Exception as e:
        fail_msg = "InterFace 接口异常：%s" % e

    # --- 方式 B：旧版 ePortal（?c=Portal&a=login，dr1003 回调） ---
    try:
        r = sess.get(root + "/", params={
            "c": "Portal", "a": "login", "callback": "dr1003", "login_method": "1",
            "user_account": ",0," + user, "user_password": pwd,
            "wlan_user_ip": wlan_user_ip, "wlan_user_ipv6": "",
            "wlan_user_mac": wlan_user_mac, "wlan_ac_ip": wlan_ac_ip,
            "wlan_ac_name": wlan_ac_name, "jsVersion": "4.1.3",
            "v": _rand_v(), "lang": "zh",
        }, headers=headers, timeout=10)
        text = r.text
        log("锐捷[dr1003] 响应：%s" % text[:160].replace("\n", " "))
        if '"result":"success"' in text.replace(" ", "") or "认证成功" in text:
            if _wait_online():
                return Result(True, "认证成功")
            return Result(True, "服务器已接受，等待放行")
        m = re.search(r'"msg"\s*:\s*"([^"]*)"', text)
        if m and m.group(1):
            fail_msg = m.group(1)
    except Exception as e:
        log("锐捷[dr1003] 异常：%s" % e)

    return Result(False, "认证失败", str(fail_msg))


# --------------------------------------------------------------------------- #
# 城市热点 Dr.COM
# --------------------------------------------------------------------------- #
def login_drcom(cfg, base, log):
    sess = _sess()
    base = base.rstrip("/")
    data = {
        "DDDDD": cfg["username"].strip(),
        "upass": cfg["password"],
        "R1": "0", "R2": "", "R3": "0", "R6": "0",
        "para": "00", "0MKKey": "123456", "buttonClicked": "",
        "err_flag": "", "username": "", "password": "",
        "user": "", "cmd": "", "Login": "",
    }
    try:
        r = sess.post(base + "/", data=data, timeout=10)
        log("Dr.COM 响应：%s" % r.text[:140].replace("\n", " "))
    except Exception as e:
        return Result(False, "连接 Dr.COM 服务器失败", str(e))
    if _wait_online():
        return Result(True, "认证成功")
    if "msga" in r.text or "成功" in r.text:
        return Result(True, "服务器已接受，等待放行")
    return Result(False, "认证失败，请检查账号密码或服务器地址", r.text[:200])


# --------------------------------------------------------------------------- #
# 通用表单（解析门户 HTML 里的 <form> 自动填充提交）
# --------------------------------------------------------------------------- #
class _FormGrabber(HTMLParser):
    def __init__(self):
        super().__init__()
        self.forms = []
        self._cur = None
        self._in_textarea = False

    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k, v in attrs}
        if tag == "form":
            self._cur = {
                "action": a.get("action", ""),
                "method": (a.get("method", "post") or "post").lower(),
                "inputs": [],
            }
            self.forms.append(self._cur)
        elif tag == "input" and self._cur is not None:
            self._cur["inputs"].append({
                "name": a.get("name", ""),
                "type": (a.get("type", "text") or "text").lower(),
                "value": a.get("value", ""),
            })
        elif tag == "select" and self._cur is not None:
            self._cur["inputs"].append({"name": a.get("name", ""), "type": "select",
                                        "value": ""})
        elif tag == "textarea" and self._cur is not None:
            self._cur["inputs"].append({"name": a.get("name", ""), "type": "textarea",
                                        "value": ""})
            self._in_textarea = True

    def handle_endtag(self, tag):
        if tag == "form":
            self._cur = None
        if tag == "textarea":
            self._in_textarea = False


def login_generic(cfg, portal_url, html, log):
    user = cfg["username"].strip()
    pwd = cfg["password"]
    grab = _FormGrabber()
    try:
        grab.feed(html or "")
    except Exception:
        pass

    cands = [f for f in grab.forms if any(i["type"] == "password" for i in f["inputs"])]
    if not cands:
        cands = grab.forms
    if not cands:
        return Result(False, "门户页面里没找到登录表单，请改用其他认证方式或填写自定义 POST")

    form = cands[0]
    root = base_of(portal_url)
    action = form["action"] or portal_url
    if action.startswith("/"):
        action = root + action
    elif not action.lower().startswith("http"):
        action = root + "/" + action

    data = {}
    for i in form["inputs"]:
        name = i["name"]
        if not name:
            continue
        t = i["type"]
        if t in ("submit", "button", "image", "reset", "file", "checkbox", "radio"):
            continue
        low = name.lower()
        if t == "password" or any(h in low for h in PWD_FIELD_HINT):
            data[name] = pwd
        elif any(h in low for h in USER_FIELD_HINT):
            data[name] = user
        else:
            data[name] = i["value"]

    sess = _sess()
    headers = {"Referer": portal_url, "Origin": root,
               "Content-Type": "application/x-www-form-urlencoded"}
    try:
        if form["method"] == "get":
            r = sess.get(action, params=data, headers=headers, timeout=10)
        else:
            r = sess.post(action, data=data, headers=headers, timeout=10)
        log("通用表单 提交到 %s，响应：%s" % (action, r.text[:140].replace("\n", " ")))
    except Exception as e:
        return Result(False, "提交表单失败", str(e))

    if _wait_online():
        return Result(True, "认证成功")
    if any(k in r.text for k in ("成功", "success", "已登录")):
        return Result(True, "服务器已接受，等待放行")
    return Result(False, "提交完成但仍未联网，可能是表单字段不匹配", r.text[:200])


# --------------------------------------------------------------------------- #
# 自定义请求
# --------------------------------------------------------------------------- #
def login_custom(cfg, log):
    url = (cfg.get("custom_url") or "").strip()
    if not url:
        return Result(False, "请填写自定义请求地址")
    if "://" not in url:
        url = "http://" + url
    tpl = cfg.get("custom_data") or ""
    user = cfg["username"].strip()
    pwd = cfg["password"]
    body = (tpl.replace("{user}", quote(user)).replace("{pwd}", quote(pwd))
            if tpl else "")
    sess = _sess()
    try:
        if (cfg.get("custom_method") or "POST").upper() == "GET":
            kv = {}
            for part in body.split("&"):
                if "=" in part:
                    k, v = part.split("=", 1)
                    kv[unquote(k)] = unquote(v)
            r = sess.get(url, params=kv, timeout=10)
        else:
            r = sess.post(url, data=body.encode("utf-8"),
                          headers={"Content-Type": "application/x-www-form-urlencoded"},
                          timeout=10)
        log("自定义请求 响应：%s" % r.text[:140].replace("\n", " "))
    except Exception as e:
        return Result(False, "请求失败", str(e))
    if _wait_online():
        return Result(True, "认证成功")
    return Result(False, "请求已发送但未联网，请检查地址与参数", r.text[:200])


# --------------------------------------------------------------------------- #
# 统一入口
# --------------------------------------------------------------------------- #
def login(cfg, log=print):
    """按配置执行一次认证，返回 Result。"""
    mode = cfg.get("mode") or "auto"
    if not cfg.get("username"):
        return Result(False, "未填写账号")
    if mode == "custom":
        return login_custom(cfg, log)

    portal = None
    base = normalize_server(cfg.get("server"))

    if mode == "auto":
        portal = detect_portal()
        if portal is not None:
            real = guess_mode(portal)
            log("探测到门户 %s，判定类型：%s" % (portal["url"][:110], real))
            if not base:
                base = base_of(portal["url"])
            mode = real
        elif base:
            # 探测不到门户但用户手填了地址，按锐捷接口试一把
            mode = "eportal"
            portal = {"url": base + "/", "html": ""}
        else:
            return Result(True, "网络已连通，无需认证")

    if mode == "srun":
        return login_srun(cfg, base, log)
    if mode == "eportal":
        url = (portal or {}).get("url") if portal else ""
        if not url:
            url = base + "/"
        return login_eportal(cfg, url, log)
    if mode == "drcom":
        return login_drcom(cfg, base or "http://1.1.1.3", log)
    if mode == "generic":
        if portal is None:
            portal = detect_portal()
        if portal is None:
            return Result(True, "网络已连通，无需认证")
        return login_generic(cfg, portal["url"], portal["html"], log)
    return Result(False, "未知认证方式：%s" % mode)

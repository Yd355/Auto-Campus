# -*- coding: utf-8 -*-
"""深澜（Srun）认证所需的加密实现：xEncode + 自定义 Base64 + MD5/SHA1。

算法与深澜门户前端 jquery.srun.portal.js 等价。
"""
import hashlib
import hmac
import math

_SRUN_ALPHA = "LVoJPiCN2R8G90yg+hmFHuacZ1OWMnrsSTXkYpUq/3dlbfKwv6xztjI7DeBE45QA"


def _ordat(msg, idx):
    if len(msg) > idx:
        return ord(msg[idx])
    return 0


def _sencode(msg, key):
    l = len(msg)
    pwd = []
    for i in range(0, l, 4):
        pwd.append(
            _ordat(msg, i)
            | _ordat(msg, i + 1) << 8
            | _ordat(msg, i + 2) << 16
            | _ordat(msg, i + 3) << 24
        )
    if key:
        pwd.append(l)
    return pwd


def _lencode(msg, key):
    l = len(msg)
    ll = (l - 1) << 2
    if key:
        m = msg[l - 1]
        if m < ll - 3 or m > ll:
            return None
        ll = m
    for i in range(0, l):
        msg[i] = (
            chr(msg[i] & 0xFF)
            + chr((msg[i] >> 8) & 0xFF)
            + chr((msg[i] >> 16) & 0xFF)
            + chr((msg[i] >> 24) & 0xFF)
        )
    if key:
        return "".join(msg)[0:ll]
    return "".join(msg)


def xencode(msg, key):
    """深澜 xEncode（XXTEA 变体）。"""
    if msg == "":
        return ""
    pwd = _sencode(msg, True)
    pwdk = _sencode(key, False)
    if len(pwdk) < 4:
        pwdk = pwdk + [0] * (4 - len(pwdk))
    n = len(pwd) - 1
    z = pwd[n]
    y = pwd[0]
    c = 0x86014019 | 0x183639A0
    m = 0
    e = 0
    p = 0
    q = math.floor(6 + 52 / (n + 1))
    d = 0
    while 0 < q:
        d = (d + c) & 0xFFFFFFFF
        e = (d >> 2) & 3
        p = 0
        while p < n:
            y = pwd[p + 1]
            m = (z >> 5) ^ (y << 2)
            m = m + ((y >> 3) ^ (z << 4) ^ (d ^ y))
            m = m + (pwdk[(p & 3) ^ e] ^ z)
            pwd[p] = (pwd[p] + m) & 0xFFFFFFFF
            z = pwd[p]
            p = p + 1
        y = pwd[0]
        m = (z >> 5) ^ (y << 2)
        m = m + ((y >> 3) ^ (z << 4) ^ (d ^ y))
        m = m + (pwdk[(p & 3) ^ e] ^ z)
        pwd[n] = (pwd[n] + m) & 0xFFFFFFFF
        z = pwd[n]
        q = q - 1
    return _lencode(pwd, False)


def srun_base64(s):
    """深澜自定义字母表的 Base64。"""
    i = 0
    b10 = 0
    x = []
    imax = len(s) - len(s) % 3
    if len(s) == 0:
        return s
    for i in range(0, imax, 3):
        b10 = (ord(s[i]) << 16) | (ord(s[i + 1]) << 8) | ord(s[i + 2])
        x.append(_SRUN_ALPHA[b10 >> 18])
        x.append(_SRUN_ALPHA[(b10 >> 12) & 63])
        x.append(_SRUN_ALPHA[(b10 >> 6) & 63])
        x.append(_SRUN_ALPHA[b10 & 63])
    i = imax
    if len(s) - imax == 1:
        b10 = ord(s[i]) << 16
        x.append(_SRUN_ALPHA[b10 >> 18] + _SRUN_ALPHA[(b10 >> 12) & 63] + "==")
    elif len(s) - imax == 2:
        b10 = (ord(s[i]) << 16) | (ord(s[i + 1]) << 8)
        x.append(_SRUN_ALPHA[b10 >> 18] + _SRUN_ALPHA[(b10 >> 12) & 63]
                 + _SRUN_ALPHA[(b10 >> 6) & 63] + "=")
    return "".join(x)


def md5_hex(text):
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def sha1_hex(text):
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def hmac_md5(key, msg):
    return hmac.new(key.encode("utf-8"), msg.encode("utf-8"), hashlib.md5).hexdigest()

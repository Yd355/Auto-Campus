# -*- coding: utf-8 -*-
"""网络连通性检测与认证门户探测。"""
import socket

import requests

HDR = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"),
    "Accept": "*/*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Connection": "close",
}

_204 = "http://connect.rom.miui.com/generate_204"
_MS = "http://www.msftconnecttest.com/connecttest.txt"
_MS_TOKEN = "Microsoft Connect Test"


def local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("223.5.5.5", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        try:
            s.close()
        except Exception:
            pass


def is_online(timeout=4):
    """真正能上网才返回 True。登录门户返回的假 200 不会被判定为已联网。"""
    try:
        r = requests.get(_MS, timeout=timeout, headers=HDR, allow_redirects=False)
        if r.status_code == 200 and _MS_TOKEN in r.text:
            return True
    except Exception:
        pass
    try:
        r = requests.get(_204, timeout=timeout, headers=HDR, allow_redirects=False)
        if r.status_code == 204:
            return True
    except Exception:
        pass
    try:
        r = requests.get("https://www.baidu.com", timeout=timeout, headers=HDR)
        if r.status_code == 200 and ("baidu.com" in r.text or "百度" in r.text):
            return True
    except Exception:
        pass
    return False


def detect_portal(timeout=8):
    """未联网时探测认证门户，返回 {'url', 'html'}；已联网或无门户返回 None。"""
    for u in (_204, _MS):
        try:
            r = requests.get(u, timeout=timeout, headers=HDR, allow_redirects=True)
        except Exception:
            continue
        if r.status_code == 204:
            return None
        if r.url.rstrip("/") == u.rstrip("/") and r.status_code == 200 and _MS_TOKEN in r.text:
            return None
        if r.url.rstrip("/") != u.rstrip("/") or r.history:
            return {"url": r.url, "html": r.text}
        if r.status_code == 200 and len(r.text) > 200:
            return {"url": r.url, "html": r.text}
    return None


def guess_mode(portal):
    """按门户特征猜测认证类型。"""
    url = (portal.get("url") or "").lower()
    html = portal.get("html") or ""
    low = html.lower()
    if "cgi-bin" in url or "srun" in url or "srun_portal" in low or "srun_bx1" in low:
        return "srun"
    if "eportal" in url or "interface.do" in url or "wlanuserip" in url:
        return "eportal"
    if "1.1.1.3" in url or "0mkkey" in low or "drcom" in low:
        return "drcom"
    return "generic"


def base_of(url):
    """取出 scheme://host[:port]。"""
    if "://" not in url:
        url = "http://" + url
    scheme, rest = url.split("://", 1)
    host = rest.split("/", 1)[0]
    return scheme + "://" + host


def normalize_server(server):
    """把用户填的服务器地址整理成可用 base url。"""
    s = (server or "").strip()
    if not s:
        return ""
    if "://" not in s:
        s = "http://" + s
    return base_of(s)

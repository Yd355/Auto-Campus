# -*- coding: utf-8 -*-
"""把 Auto Campus 整合成一个发布用 zip（排除虚拟环境与构建缓存）。"""
import os
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(ROOT, "dist")
OUT = os.path.join(os.path.dirname(ROOT), "Auto Campus v2.0.zip")
TOP = "Auto Campus v2.0"

EXCLUDE_DIRS = {".venv", "build", "__pycache__", ".workbuddy"}
EXCLUDE_EXT = {".pyc", ".pyo", ".toc", ".spec"}


def add_file(zf, src, arc):
    if not os.path.exists(src):
        print("  [跳过] 不存在:", src)
        return
    zf.write(src, arc)
    print("  + %s  (%.1f KB)" % (arc, os.path.getsize(src) / 1024))


def main():
    if os.path.exists(OUT):
        os.remove(OUT)
    print("打包 →", OUT)
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        # 1) 开箱即用
        add_file(z, os.path.join(DIST, "Auto Campus.exe"), TOP + "/Auto Campus.exe")
        add_file(z, os.path.join(DIST, "使用说明.txt"), TOP + "/使用说明.txt")
        add_file(z, os.path.join(ROOT, "README.md"), TOP + "/README.md")

        # 2) 源码
        add_file(z, os.path.join(ROOT, "main.py"), TOP + "/源码/main.py")
        add_file(z, os.path.join(ROOT, "package.py"), TOP + "/源码/package.py")
        for sub in ("src", "tests", "assets"):
            d = os.path.join(ROOT, sub)
            if not os.path.isdir(d):
                continue
            for name in sorted(os.listdir(d)):
                p = os.path.join(d, name)
                if os.path.isdir(p) or name in EXCLUDE_DIRS:
                    continue
                if os.path.splitext(name)[1].lower() in EXCLUDE_EXT:
                    continue
                if sub == "assets" and name.startswith("cover_"):
                    continue
                if sub == "tests" and not name.endswith(".py"):
                    continue          # 测试过程的截图不进发布包
                add_file(z, p, "%s/源码/%s/%s" % (TOP, sub, name))

        # 3) 宣传素材
        base = os.path.dirname(ROOT)
        for src, name in (
            (os.path.join(base, "视频封面_横版1920x1080.png"), "视频封面_横版1920x1080.png"),
            (os.path.join(base, "视频封面_竖版1080x1920.png"), "视频封面_竖版1080x1920.png"),
            (os.path.join(ROOT, "tests", "demo_night.png"), "界面截图_夜间主题.png"),
        ):
            add_file(z, src, "%s/宣传素材/%s" % (TOP, name))

    print("\n完成：%s  (%.1f MB)" % (OUT, os.path.getsize(OUT) / 1024 / 1024))
    with zipfile.ZipFile(OUT) as z:
        print("共 %d 个文件" % len(z.namelist()))


if __name__ == "__main__":
    main()

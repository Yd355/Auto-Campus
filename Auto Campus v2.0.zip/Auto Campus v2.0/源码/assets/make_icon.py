# -*- coding: utf-8 -*-
"""生成 WiFi 样式的应用图标（assets/wifi.png 与 assets/wifi.ico）。"""
import os

from PIL import Image, ImageDraw

S = 256
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)

# 蓝色圆角方块底
m = 6
d.rounded_rectangle([m, m, S - m, S - m], radius=58, fill=(37, 99, 235, 255))

# WiFi：三段上弧 + 中心圆点
cx, cy = 128, 150
white = (255, 255, 255, 255)
for r in (44, 74, 104):
    d.arc([cx - r, cy - r, cx + r, cy + r], 225, 315, fill=white, width=19)
d.ellipse([cx - 17, cy - 17, cx + 17, cy + 17], fill=white)

out_dir = os.path.dirname(os.path.abspath(__file__))
img.save(os.path.join(out_dir, "wifi.png"))
img.save(os.path.join(out_dir, "wifi.ico"),
         sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("icon generated:", os.path.join(out_dir, "wifi.ico"))

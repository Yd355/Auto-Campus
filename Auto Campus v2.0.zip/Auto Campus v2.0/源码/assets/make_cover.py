# -*- coding: utf-8 -*-
"""生成视频封面（16:9 与 9:16 两版）。"""
import os

from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
SHOT = os.path.join(os.path.dirname(HERE), "tests", "demo_night.png")

F_BOLD = "C:/Windows/Fonts/msyhbd.ttc"
F_REG = "C:/Windows/Fonts/msyh.ttc"

BG_TOP = (10, 13, 20)
BG_BOT = (26, 34, 51)
WHITE = (255, 255, 255, 255)
MUTED = (150, 162, 182, 255)
BLUE = (77, 141, 255, 255)
BLUE_SOLID = (37, 99, 235, 255)


def font(path, size):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def gradient(w, h):
    img = Image.new("RGB", (w, h))
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / max(1, h - 1)
        c = tuple(int(BG_TOP[i] + (BG_BOT[i] - BG_TOP[i]) * t) for i in range(3))
        d.line([(0, y), (w, y)], fill=c)
    return img.convert("RGBA")


def glow(w, h, cx, cy, r, color=(37, 99, 235), alpha=70):
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color + (alpha,))
    return layer.filter(ImageFilter.GaussianBlur(r // 3))


def wifi_marks(w, h, cx, cy, radii, width, color=(90, 140, 255, 34)):
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for r in radii:
        d.arc([cx - r, cy - r, cx + r, cy + r], 225, 315, fill=color, width=width)
    return layer


def paste_shot(canvas, box, radius=18):
    x, y, w, h = box
    shot = Image.open(SHOT).convert("RGBA").resize((w, h), Image.LANCZOS)
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], radius=radius, fill=255)
    # 投影
    shadow = Image.new("RGBA", (w + 80, h + 80), (0, 0, 0, 0))
    ImageDraw.Draw(shadow).rounded_rectangle(
        [40, 40, 40 + w, 40 + h], radius=radius, fill=(0, 0, 0, 170))
    shadow = shadow.filter(ImageFilter.GaussianBlur(26))
    canvas.alpha_composite(shadow, (x - 40, y - 30))
    canvas.paste(shot, (x, y), mask)
    ImageDraw.Draw(canvas).rounded_rectangle(
        [x, y, x + w - 1, y + h - 1], radius=radius, outline=(70, 82, 108, 255), width=2)


def pill(draw, xy, text, f, pad=(24, 14), bg=BLUE_SOLID, fg=WHITE):
    x, y = xy
    tw = draw.textlength(text, font=f)
    th = f.size
    draw.rounded_rectangle([x, y, x + tw + pad[0] * 2, y + th + pad[1] * 2],
                           radius=(th + pad[1] * 2) // 2, fill=bg)
    draw.text((x + pad[0], y + pad[1] - 2), text, font=f, fill=fg)
    return tw + pad[0] * 2


def bullet(draw, x, y, text, f, fg=WHITE, dot=BLUE):
    r = max(4, f.size // 5)
    draw.ellipse([x, y + f.size // 2 - r, x + r * 2, y + f.size // 2 + r], fill=dot)
    draw.text((x + r * 3 + 10, y), text, font=f, fill=fg)


def brand(draw, x, y, size, anchor_left=True):
    """画 WiFi 小图标 + 文字。返回总宽度。"""
    f = font(F_BOLD, size)
    text = "Auto Campus"
    tw = int(draw.textlength(text, font=f))
    cx = x + size // 2
    cy = y + size // 2 + size // 8
    for r in (int(size * 0.24), int(size * 0.42), int(size * 0.60)):
        draw.arc([cx - r, cy - r, cx + r, cy + r], 225, 315, fill=BLUE, width=max(3, size // 12))
    rr = max(3, size // 12)
    draw.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], fill=BLUE)
    draw.text((x + size + 16, y + size // 2 - f.size // 2 - 2), text, font=f, fill=WHITE)
    return size + 16 + tw


def build(w, h, out):
    scale = w / 1920.0
    img = gradient(w, h)
    img = Image.alpha_composite(img, glow(w, h, int(w * 0.86), int(h * 0.20),
                                          int(w * 0.30), alpha=60))
    img = Image.alpha_composite(img, wifi_marks(
        w, h, int(w * 0.98), int(h * 1.02),
        [int(r * scale) for r in (260, 420, 580, 740)], int(30 * scale)))

    if w > h:      # 横版 16:9
        shot_w = int(660 * scale)
        shot_h = int(shot_w * 700 / 660)
        sx = w - int(120 * scale) - shot_w
        sy = (h - shot_h) // 2 + int(20 * scale)
        paste_shot(img, (sx, sy, shot_w, shot_h), radius=int(18 * scale))

        d = ImageDraw.Draw(img)
        pill(d, (int(120 * scale), int(92 * scale)), "用 WorkBuddy 做的",
             font(F_REG, int(30 * scale)))
        d.text((int(120 * scale), int(196 * scale)), "校园网开机自动认证",
               font=font(F_BOLD, int(96 * scale)), fill=WHITE)
        d.text((int(120 * scale), int(320 * scale)), "从此不用手动登录",
               font=font(F_BOLD, int(96 * scale)), fill=BLUE)
        items = ["开机自动联网 · 掉线自动重连",
                 "真实联网判定 · 不再误报“未连接”",
                 "深澜 / 锐捷 / Dr.COM 全自动识别"]
        for i, t in enumerate(items):
            bullet(d, int(124 * scale), int(474 * scale) + i * int(72 * scale),
                   t, font(F_REG, int(38 * scale)))
        brand(d, int(120 * scale), int(944 * scale), int(46 * scale))
        f_small = font(F_REG, int(28 * scale))
        tail = "深澜 · 锐捷 ePortal · Dr.COM"
        d.text((w - int(120 * scale) - d.textlength(tail, font=f_small),
                int(958 * scale)), tail, font=f_small, fill=MUTED)
    else:          # 竖版 9:16（按 1080 宽为基准单独排版）
        vs = w / 1080.0
        d = ImageDraw.Draw(img)
        f_pill = font(F_REG, int(34 * vs))
        pill_text = "用 WorkBuddy 做的"
        pw = d.textlength(pill_text, font=f_pill) + int(56 * vs)
        pill(d, ((w - pw) / 2, int(178 * vs)), pill_text, f_pill,
             pad=(int(28 * vs), int(16 * vs)))

        for text, color, y in (("校园网开机自动认证", WHITE, 292),
                               ("从此不用手动登录", BLUE, 404)):
            f = font(F_BOLD, int(92 * vs))
            d.text(((w - d.textlength(text, font=f)) / 2, int(y * vs)),
                   text, font=f, fill=color)

        items = ["开机自动联网 · 掉线自动重连",
                 "真实联网判定 · 不再误报",
                 "深澜 / 锐捷 / Dr.COM 全自动识别"]
        f_b = font(F_REG, int(36 * vs))
        for i, t in enumerate(items):
            tw = d.textlength(t, font=f_b)
            x = (w - tw) / 2 + int(14 * vs)
            bullet(d, x - int(40 * vs), int((546 + i * 76) * vs), t, f_b)

        shot_w = int(810 * vs)
        shot_h = int(shot_w * 700 / 660)
        paste_shot(img, ((w - shot_w) // 2, int(792 * vs), shot_w, shot_h),
                   radius=int(20 * vs))

        f_brand = font(F_BOLD, int(54 * vs))
        bw = int(54 * vs) + int(18 * vs) + d.textlength("Auto Campus", font=f_brand)
        brand(d, int((w - bw) / 2), int(1706 * vs), int(54 * vs))

    img.convert("RGB").save(out, quality=95)
    print("saved:", out, img.size)


build(1920, 1080, os.path.join(HERE, "cover_16x9.png"))
build(1080, 1920, os.path.join(HERE, "cover_9x16.png"))

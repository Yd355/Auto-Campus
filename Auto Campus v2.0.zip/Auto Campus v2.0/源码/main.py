# -*- coding: utf-8 -*-
"""校园网自动登录工具 —— 程序入口。

用法：
    python main.py              # 打开界面
    python main.py --minimized  # 最小化启动（开机自启时使用）
    python main.py --check      # 命令行自检：只检测网络，不开界面
    python main.py --login      # 命令行认证一次，不开界面
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src import config, netcheck, portal  # noqa: E402


def main():
    args = set(sys.argv[1:])

    if "--check" in args:
        print("在线" if netcheck.is_online() else "离线")
        return 0

    if "--login" in args:
        cfg = config.load()
        if not cfg.get("username"):
            print("配置里没有账号，请先打开界面填写")
            return 2
        res = portal.login(cfg, log=lambda m: print("  " + str(m)))
        print("结果：%s %s" % (res.message, res.detail))
        return 0 if res.ok else 1

    from src.app import run
    run(start_minimized="--minimized" in args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
